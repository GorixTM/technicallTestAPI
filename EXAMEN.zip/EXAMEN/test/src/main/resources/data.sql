INSERT INTO ITEM (nombre, categoria, precio, stock) VALUES
('Laptop Ultrabook', 'Electrónica', 24000.00, 15),
('Monitor Curvo 27"', 'Electrónica', 7020.00, 5),
('Mouse Inalámbrico', 'Periféricos', 500.00, 50),
('Teclado Mecánico', 'Periféricos', 1500.00, 20),
('Mochila Ejecutiva', 'Accesorios', 915.00, 30),
('Audífonos Noise Cancelling', 'Electrónica', 4000.00, 10);