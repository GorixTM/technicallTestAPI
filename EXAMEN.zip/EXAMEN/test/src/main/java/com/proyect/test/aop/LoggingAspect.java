package com.proyect.test.aop;

import com.proyect.test.model.LogEntry;
import com.proyect.test.repository.LogRepository;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private final LogRepository logRepository;

    public LoggingAspect(LogRepository logRepository) {
        this.logRepository = logRepository;
    }

     // Pointcut: Selecciona todos los métodos dentro del paquete 'controller'.

    @Pointcut("within(com.proyect.test.controller..*)")
    public void controllerMethods() {}

    @Around("controllerMethods()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {

        long startTime = System.currentTimeMillis();
        String methodName = joinPoint.getSignature().toShortString();
        String usuario = getAuthenticatedUser();
        Object[] args = joinPoint.getArgs();

        // Inicializamos la entidad LogEntry
        LogEntry logEntry = new LogEntry();
        logEntry.setMetodoEjecutado(methodName);
        logEntry.setUsuario(usuario);
        logEntry.setArgumentos(sanitizeArgs(args));

        try {
            // Ejecutar el método del controlador
            Object result = joinPoint.proceed();

            // LOG de ÉXITO
            long duration = System.currentTimeMillis() - startTime;
            logEntry.setDuracionMs(duration);
            logEntry.setResultado(result != null ? result.getClass().getSimpleName() : "void");
            logEntry.setTipoEvento("Éxito");

            log.info("<< FIN | {}() - {}ms >> Usuario: {}", methodName, duration, usuario);

            return result;
        } catch (Throwable e) {
            // LOG de ERROR
            long duration = System.currentTimeMillis() - startTime;

            logEntry.setDuracionMs(duration);
            logEntry.setResultado("Error: " + e.getMessage());
            logEntry.setTipoEvento("Error");

            log.error("!! ERROR | {}() - {}ms >> Usuario: {} - Error: {}", methodName, duration, usuario, e.getMessage());

            throw e; // Relanza la excepción
        } finally {
            // PERSISTE LOS LOG (Independientemente del resultado)
            try {
                logRepository.save(logEntry);
            } catch (Exception ex) {
                // Manejo de error si la BD falla al registrar la bitácora
                log.error("Fallo al guardar la entrada de log en BD: {}", ex.getMessage());
            }
        }
    }

   // Obtiene el nombre del usuario autenticado del contexto de Spring Security.

    private String getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        // Verificar si hay autenticación y no es el usuario anónimo por defecto
        if (authentication != null && authentication.isAuthenticated() &&
                !(authentication.getPrincipal() instanceof String &&
                        authentication.getPrincipal().equals("anonymousUser"))) {
            return authentication.getName();
        }
        return "ANÓNIMO/PÚBLICO";
    }

     // Convierte los argumentos a String, limitando la longitud.

    private String sanitizeArgs(Object[] args) {
        if (args == null || args.length == 0) return "[]";
        String argsString = Arrays.toString(args);
        return argsString.substring(0, Math.min(argsString.length(), 250));
    }

}