package com.proyect.test.controller;

import com.proyect.test.model.EncryptionRequest;
import com.proyect.test.utils.EncryptionUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

@RestController
@RequestMapping("/api/cipher")
@SecurityRequirement(name = "bearerAuth") // Protegido por JWT
@Tag(name = "Cifrado AES", description = "Servicio para cifrar una cadena con AES/CBC/PKCS5Padding.")
public class EncryptionController {

    private final EncryptionUtil encryptionUtil;

    public EncryptionController(EncryptionUtil encryptionUtil) {
        this.encryptionUtil = encryptionUtil;
    }

    @Operation(summary = "Cifrar Cadena",
            description = "Recibe una cadena de cualquier longitud y la cifra usando la llave y el IV predefinidos. Retorna el resultado en Base64.")
    @PostMapping("/encrypt")
    public ResponseEntity<Map<String, String>> encryptString(@RequestBody EncryptionRequest request) {
        try {
            String encrypted = encryptionUtil.encrypt(request.getCadena());
            return ResponseEntity.ok(Map.of(
                    "cadena_original", request.getCadena(),
                    "cadena_cifrada_base64", encrypted
            ));
        } catch (Exception e) {
            // Manejo de errores de cifrado/algoritmo
            return ResponseEntity.internalServerError().body(Map.of("error", "Fallo al cifrar: " + e.getMessage()));
        }
    }

    // Endpoint opcional: Ayuda a verificar que el cifrado es reversible.
    @Operation(summary = "Descifrar Cadena (DEBUG)", description = "Recibe una cadena cifrada en Base64 y la descifra.")
    @PostMapping("/decrypt")
    public ResponseEntity<Map<String, String>> decryptString(@RequestBody EncryptionRequest request) {
        try {
            String decrypted = encryptionUtil.decrypt(request.getCadena());
            return ResponseEntity.ok(Map.of(
                    "cadena_descifrada", decrypted
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Fallo al descifrar (Clave o formato incorrecto): " + e.getMessage()));
        }
    }
}