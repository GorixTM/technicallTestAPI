package com.proyect.test.service;

import com.proyect.test.model.PokemonDTO;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class PokeApiService {

    private final WebClient webClient;
    private static final String POKEMON_PATH = "pokemon/ditto";

    public PokeApiService(WebClient webClient) {
        this.webClient = webClient;
    }

    // Consume la API externa y retorna el objeto mapeado

    public PokemonDTO getDittoPokemon() {
        // Construye la URI y realiza la petición
        return webClient.get()
                .uri(POKEMON_PATH)
                .retrieve()
                .bodyToMono(PokemonDTO.class) // Convierte a PokemonDTO
                .block(); // Bloquea hasta obtener el resultado
    }
}