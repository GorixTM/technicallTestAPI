package com.proyect.test.repository;

import com.proyect.test.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ItemRepository extends JpaRepository<Item, Long> {

    // Metodo para buscar por nombre e ignorar mayúsculas/minúsculas
    List<Item> findByNombreContainingIgnoreCase(String nombre);
}