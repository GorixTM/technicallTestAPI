package com.proyect.test.service;

import com.proyect.test.model.Item;
import com.proyect.test.repository.ItemRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ItemService {

    private final ItemRepository itemRepository;

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<Item> getItems(String nombre) {
        // Regresa el catálogo completo si el nombre es nulo o vacío
        if (nombre == null || nombre.trim().isEmpty()) {
            return itemRepository.findAll();
        } else {
            // Filtra por nombre usando el método del repositorio
            return itemRepository.findByNombreContainingIgnoreCase(nombre);
        }
    }
}