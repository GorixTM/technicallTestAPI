package com.proyect.test.model;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;
import java.util.List;
import lombok.Getter;

@Getter
public class User implements UserDetails {

    // Contraseña "password" codificada con clase PasswordEncoderTool
    private final String username = "testuser";
    private final String password = "$2a$10$yNOVpR7JI1lI00c9yKHCKO69DY8Lohh3DZi09IZotSD0X07ZSWXEi";
    private final Collection<? extends GrantedAuthority> authorities = List.of(() -> "ROLE_USER");

    // Implementaciones de UserDetails
    @Override public Collection<? extends GrantedAuthority> getAuthorities() { return authorities; }
    @Override public String getPassword() { return password; }
    @Override public String getUsername() { return username; }
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return true; }
}