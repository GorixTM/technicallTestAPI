package com.proyect.test.utils;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

// ESTA CLASE SOLO ES DE UTILIDAD PARA GENERAR LAS CLAVES

public class KeyGeneratorUtility {

    public static KeyPair generateRsaKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        return keyPairGenerator.generateKeyPair();
    }

    public static void printKeys() throws NoSuchAlgorithmException {
        KeyPair keyPair = generateRsaKeyPair();

        System.out.println("--- PUBLIC KEY (X.509 Base64) ---");
        System.out.println(Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded()));
        System.out.println("--- PRIVATE KEY (PKCS#8 Base64) ---");
        System.out.println(Base64.getEncoder().encodeToString(keyPair.getPrivate().getEncoded()));
    }
}