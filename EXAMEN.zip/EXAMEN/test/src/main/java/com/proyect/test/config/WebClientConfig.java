package com.proyect.test.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient webClient() {
        // Configuramos la URL base para la PokeAPI
        return WebClient.builder()
                .baseUrl("https://pokeapi.co/api/v2/")
                .build();
    }
}