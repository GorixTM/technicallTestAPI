package com.proyect.test.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.security.Key;

@Component
public class EncryptionUtil {

    // Mecanismo de cifrado solicitado
    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";

    // Llave Secreta y Vector de Inicialización (16 bytes = 128 bits para AES)
    private static final String KEY_STRING = "ThisIsA16ByteKey";
    private static final String IV_STRING = "RandomInitVector";

    private final Key secretKey;
    private final IvParameterSpec ivSpec;

    public EncryptionUtil() {
        // Inicializa la clave secreta y el vector IV
        this.secretKey = new SecretKeySpec(KEY_STRING.getBytes(StandardCharsets.UTF_8), "AES");
        this.ivSpec = new IvParameterSpec(IV_STRING.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Cifra la cadena de entrada usando el mecanismo AES/CBC/PKCS5Padding.
     * @param plainText Cadena a cifrar.
     * @return La cadena cifrada, codificada en Base64.
     */

    public String encrypt(String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
        byte[] cipherText = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(cipherText);
    }

    /**
     * Descifra una cadena codificada en Base64. (Utilizado para prueba)
     * @param cipherText Cadena cifrada en Base64.
     * @return La cadena descifrada.
     */

    public String decrypt(String cipherText) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
        byte[] original = cipher.doFinal(Base64.getDecoder().decode(cipherText));
        return new String(original, StandardCharsets.UTF_8);
    }
}