package com.proyect.test.controller;

import com.proyect.test.model.Item;
import com.proyect.test.service.ItemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/items")
@SecurityRequirement(name = "bearerAuth") // Protegido por JWT
@Tag(name = "Catálogo de Items", description = "Servicio para obtener el catálogo de productos con filtrado.")
public class ItemController {

    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @Operation(summary = "Obtener Catálogo de Items",
            description = "Regresa el catálogo completo o filtrado. Ejemplo de filtro: /api/items?nombre=Lap")
    @GetMapping
    public List<Item> getItems(@RequestParam(required = false) String nombre) {
        return itemService.getItems(nombre);
    }
}