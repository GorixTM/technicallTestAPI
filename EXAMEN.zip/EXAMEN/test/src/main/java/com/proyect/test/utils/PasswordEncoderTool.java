package com.proyect.test.utils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

// CLASE SOLO PARA GENERAR PASS

public class PasswordEncoderTool {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String password = "password";
        String encodedPassword = encoder.encode(password);

        System.out.println("------------------------------------------");
        System.out.println("PASSWORD CODIFICADO");
        System.out.println(encodedPassword);
        System.out.println("------------------------------------------");
    }
}