package com.proyect.test.model;

import lombok.Data;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class PokemonDTO {
    private Long id;
    private String name;
    @JsonProperty("base_experience") // Mapeo de camelCase a snake_case de la API
    private Integer baseExperience;
    private List<AbilityWrapper> abilities;

    @Data
    public static class AbilityWrapper {
        private NamedApiResource ability;
        @JsonProperty("is_hidden")
        private boolean isHidden;
        private int slot;
    }

    @Data
    public static class NamedApiResource {
        private String name;
        private String url;
    }
}