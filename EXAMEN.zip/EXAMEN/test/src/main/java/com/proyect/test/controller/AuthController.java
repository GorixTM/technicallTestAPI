package com.proyect.test.controller;

import com.proyect.test.model.User;
import com.proyect.test.service.TokenService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Autenticación", description = "Servicio para obtener un token JWT (OAuth 2)")
public class AuthController {

    private final TokenService tokenService;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private final UserDetails testUser = new User();

    public AuthController(TokenService tokenService, AuthenticationManager authenticationManager, PasswordEncoder passwordEncoder) {
        this.tokenService = tokenService;
        this.authenticationManager = authenticationManager;
        this.passwordEncoder = passwordEncoder;
    }

    @Operation(summary = "Generar Token JWT", description = "Autentica con usuario/contraseña para recibir un token JWT.")
    @PostMapping("/token")
    public String token(@RequestParam("username") String username, @RequestParam("password") String password) {

        // validación de credenciales
        if (!testUser.getUsername().equals(username) || !passwordEncoder.matches(password, testUser.getPassword())) {
            throw new SecurityException("Credenciales inválidas.");
        }
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, password)
        );

        // Generar y regresar el token
        return tokenService.generateToken(authentication);
    }
}