package com.proyect.test.controller;

import com.proyect.test.model.PokemonDTO;
import com.proyect.test.service.PokeApiService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/external")
@SecurityRequirement(name = "bearerAuth") // Protegido por JWT
@Tag(name = "API Externa", description = "Servicio que consume PokeAPI y publica su respuesta.")
public class PokeApiController {

    private final PokeApiService pokeApiService;

    public PokeApiController(PokeApiService pokeApiService) {
        this.pokeApiService = pokeApiService;
    }

    @Operation(summary = "Obtener Datos de Ditto",
            description = "Consumo del API: https://pokeapi.co/api/v2/pokemon/ditto y retorna el JSON.")
    @GetMapping("/ditto")
    public PokemonDTO getDitto() {
        return pokeApiService.getDittoPokemon();
    }
}