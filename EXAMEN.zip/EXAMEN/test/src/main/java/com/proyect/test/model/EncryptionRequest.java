package com.proyect.test.model;

import lombok.Data;

@Data
public class EncryptionRequest {
    private String cadena;
}